﻿controllers.controller('reportController', ['$scope',
    function ($scope) {
    }]);