﻿controllers.controller('profileController', ['$scope',
    function ($scope) {
    }]);