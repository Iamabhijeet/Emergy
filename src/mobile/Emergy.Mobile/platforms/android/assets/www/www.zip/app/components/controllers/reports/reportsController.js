﻿controllers.controller('reportsController', ['$scope',
    function ($scope) {
    }]);