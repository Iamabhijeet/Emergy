﻿controllers.controller('settingsController', ['$scope',
    function ($scope) {
    }]);